//**********************************************************
// Filename: cSymbolTable.h
// Purpose: cSymbolTable class declaration.
// Author: Rowan Parker
// Date: 01/17/2019

#pragma once
#include <iostream>
#include <unordered_map>
#include <vector>
#include <string>
#include "cSymbol.h"

using std::unordered_map;
using std::vector;
using std::string;

class cSymbolTable
{
    public:
        //**************************************************
        // Method: cSymbolTable
        // Parameters: none
        // Purpose: instantiate new cSymbolTable object.
        cSymbolTable() : m_table(), m_scope(0)
        { 
            m_table.push_back(unordered_map<string, cSymbol *>());
        }

        //**************************************************
        // Method: IncreaseScope
        // Parameters: none
        // Purpose: creates new map to hold cSymbols and
        //          increments that scope counter
        void IncreaseScope()
        {
            m_table.push_back(unordered_map<string, cSymbol *>());
            ++m_scope;
        } 

        //**************************************************
        //Method: DecreaseScope
        //Parameters: none
        //Purpose: pops the last map of cSymbols and
        //         decremeants the scope counter
        void DecreaseScope()
        {
            m_table.pop_back();
            --m_scope;
        }

        //**************************************************
        // Method: Insert
        // Parameters: cSymbol *
        // Purpose: inserts a cSymbol into the current scope.
        cSymbol * Insert(string key)
        {
            // search current scope for existing symbol
            cSymbol * symbol = LocalLookup(key);
                       
            // if not found, create new symbol
            if (symbol == nullptr)
            {
                symbol = new cSymbol(key);
                m_table[m_scope].insert({key, symbol}); 
            } 

            // return symbol
            return symbol;
        }

        //**************************************************
        // Method: GlobalLookup 
        // Parameters: string
        // Purpose: finds a cSymbol based on name. First
        //          searches current scope, then searches
        //          through scopes sequentially. Returns
        //          the address of the cSymbol. If not
        //          found, returns nullptr.
        cSymbol * GlobalLookup(string key)
        {
           cSymbol * symbol = nullptr;

           // preform local lookup
           symbol = LocalLookup(key);

           // if not found locally, begin global search
           if (symbol == nullptr)
           {
               // begin looping through scopes
               while (m_scope >= 0 && symbol == nullptr)
               {
                   // if found, assign symbol
                   if (m_table[m_scope].count(key) != 0)
                   {
                       symbol = m_table[m_scope].at(key);
                   }
                   // else, decrease scope
                   else
                   {
                       DecreaseScope();
                   }
                }        
           }
          
            return symbol;
        }

        //**************************************************
        // Method: LocalLookup 
        // Parameters: string
        // Purpose: finds a cSymbol based on name. Only
        //          searches current scope. Returns the 
        //          address of the cSymbol. If not found,
        //          returns nullptr.
        cSymbol * LocalLookup(string key)
        {                     
            cSymbol * symbol = nullptr;
            
            // if found, assign symbol
            if (m_table.back().count(key) != 0)
            {
                symbol = m_table.back().at(key);
            }
                        
            return symbol;
        }

    private:
        vector<unordered_map<string, cSymbol *>> m_table;
        int m_scope;
};
