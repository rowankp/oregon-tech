#pragma once
//**************************************
// cSymbolTable.h
//
// Defines a nested symbol table.
// Individual levels of the symbol table use a std::unordered_map from the STL
//
// Author: Phil Howard 
// phil.howard@oit.edu
//

#include <string>

using std::string;

#include "cSymbol.h"

class cSymbolTable
{
    public:
        // Bodus typedef; Not valid for a real implementation.
        // This is supposed to be a single table. The whole table is a stack
        // of these.
        typedef cSymbolTable symbolTable_t;

        // Increasing the scope must create a symbol table, so we call
        // that function to do the actual work of creating the object
        cSymbolTable()
        { 
            IncreaseScope();

            // NOTE: the following code is TEMPORARY code. It exists only to
            // get the first test to pass. At some point during Lab 4 this code
            // must be replaced (or at least removed).
            new cSymbol("&junk1");
            new cSymbol("&junk2");
            new cSymbol("&junk3");
        }

        // Increase the scope: add a level to the nested symbol table
        // Return value is the newly created scope
        symbolTable_t *IncreaseScope()
        {
            return nullptr;
        }

        // Decrease the scope: remove the outer-most scope.
        // Returned value is the outer-most scope AFTER the pop.
        //
        // NOTE: do NOT clean up memory after poping the table. Parts of the
        // AST will probably contain pointers to symbols in the popped table.
        symbolTable_t *DecreaseScope()
        {
            return nullptr;
        }

        // insert a symbol into the table
        // Assumes the symbol is not already in the table
        void Insert(cSymbol *sym)
        {
        }

        // Do a lookup in the nested table. Return the symbol for the outer-most
        // match. 
        // Returns nullptr if no match is found.
        cSymbol *Find(string name)
        {
            return nullptr;
        }

        // Find a symbol in the inner-most scope.
        // Returns nullptr if the symbol is not found.
        cSymbol *FindLocal(string name)
        {
            return nullptr;
        }

    protected:
};

// Declaration for the global symbol table.
// Definition is in main.cpp
extern cSymbolTable g_SymbolTable;
