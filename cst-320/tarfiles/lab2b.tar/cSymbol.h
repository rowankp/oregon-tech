#pragma once
//*********************************************************
// filename: cSymbol.h
// purpose: cSymbol class declaration. cSymbols are 
//          objects that represent identifiers and other 
//          such strings in the compiler.
// author: Rowan Parker (rowan.parker@oit.edu)
// date: 01/28/20

#include "tokens.h"
#include <string>
#include <utility>

using std::string;

class cSymbol
{
    public:
        //**************************************************
        // method: cSymbol
        // parameters: string, int
        // purpose: instantiates a new cSymbol object
        cSymbol(string name, int id = -1)
        {
            m_name = name;

            if (id == -1)
            {
                m_id = ++nextId;
                m_type = IDENTIFIER;
            }
            else
            {
                m_id = id;
                m_type = id;
            }
        }

        //**************************************************
        // method: ToString
        // parameters: none
        // purpose: prints the data members of cSymbol
        string ToString()
        {
            string result("<sym id=\"");
            result += std::to_string(m_id);
            result += "\" name=\"" + m_name + "\" />";

            return result;
        }

        //**************************************************
        // method: GetName
        // parameters: none
        // purpose: return the name of the cSymbol
        string GetName()
        { 
            return m_name; 
        }

        //**************************************************
        // method: GetType
        // parameters: none
        // purpose: return the type of the cSymbol
        long long GetType()
        {
            return m_type;
        }

        //**************************************************
        // method: SetType
        // parameters: long long
        // purpose: set the type of the cSymbol
        void SetType(long long type)
        {
            m_type = type;
        }

    protected:
        static long long nextId;    
        long long m_id;            
        long long m_type;
        string m_name;
};
