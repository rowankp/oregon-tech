//**********************************************************
// filename: cArrayDeclNode
// purpose: defines an ast node for array declarations.
// author: Rowan Parker (rowan.prker@oit.edu)
// date: 02/09/2020

#pragma once
#include "cDeclNode.h"
#include "cSymbol.h"
#include "cSymbolTable.h"
#include "cDeclsNode.h"

class cArrayDeclNode : public cDeclNode
{
    public:
        //**************************************************
        // constructor
        cArrayDeclNode(cSymbol * name, cDeclNode * type,  cDeclsNode * decls) : cDeclNode() 
        {
            if (name != nullptr && decls != nullptr && type != nullptr)
            {  
                if(symbolTable.GlobalLookup(name->GetName()) == name)
                {
                   name = new cSymbol(name->GetName());
                }

                symbolTable.Insert(name);
                name->SetDecl(this);
                name->SetIsType(true);

                AddChild(name);
                AddChild(type);
                AddChild(decls);    
            }
        }
       
       //***************************************************
       // returns a string with the node type
       virtual string NodeType() { return "array"; } 

       //***************************************************
       // defines the visit method for this node
       virtual void Visit(cVisitor * visitor) { visitor->Visit(this); }
};
