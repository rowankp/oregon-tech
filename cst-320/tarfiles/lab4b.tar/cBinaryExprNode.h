//**********************************************************
// filename: cBinaryExprNode.h
// purpose: defines an AST node for binary expressions.
// author: Rowan Parker (rowan.parker@oit.edu)
// date: 02/01/2020

#pragma once
#include "cAstNode.h"
#include "cExprNode.h"
#include "cOpNode.h"

class cBinaryExprNode : public cExprNode
{
    public:

        //**************************************************
        // constructor
        cBinaryExprNode(cExprNode * expr1, cOpNode * op, cExprNode * expr2) 
            : cExprNode()
        {
            if (expr1 != nullptr)
            {
                AddChild(expr1);
            }

            if (op != nullptr)
            {
                AddChild(op);
            }

            if (expr2 != nullptr)
            {
                AddChild(expr2);
            }
        }

        //**************************************************
        // returns a string with the node type
        virtual string NodeType() { return string("expr"); }

        //**************************************************
        // defines the visit method for this node
        virtual void Visit(cVisitor *visitor) { visitor->Visit(this); }
};
