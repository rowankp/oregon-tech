//**********************************************************
// filename: cVarDeclNode
// purpose: defines a base class for all var declarations.
// author: Rowan Parker (rowan.prker@oit.edu)
// date: 02/01/2020

#pragma once
#include "cSymbolTable.h"
#include "cDeclNode.h"
#include "cBaseTypeNode.h"
#include "cSymbol.h"

class cVarDeclNode : public cDeclNode
{
    public:
        //**************************************************
        // constructor
        cVarDeclNode(cDeclNode * type, cSymbol * symbol) : cDeclNode() 
        {
            if (type != nullptr && symbol != nullptr)
            {  
                if(symbolTable.GlobalLookup(symbol->GetName()) == symbol)
                {
                   symbol = new cSymbol(symbol->GetName());
                }

                symbolTable.Insert(symbol);
                symbol->SetDecl(type);
                
                AddChild(type);
                AddChild(symbol);    
            }
        }
       
        //**************************************************
        // m_type accesor
       cBaseTypeNode * GetType() { return m_type; }
       
       //***************************************************
       // m_symbol accessor
       cSymbol * GetSymbol() { return m_symbol; }

       //***************************************************
       // returns a string with the node type
       virtual string NodeType() { return "var_decl"; } 

       //***************************************************
       // defines the visit method for this node
       virtual void Visit(cVisitor * visitor) { visitor->Visit(this); }

    protected:
        cBaseTypeNode * m_type;
        cSymbol * m_symbol;
};
