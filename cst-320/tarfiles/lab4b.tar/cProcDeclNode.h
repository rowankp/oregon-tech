//**********************************************************
// filename: cProcDeclNode
// purpose: defines an ast node for  procedure declarations.
// author: Rowan Parker (rowan.prker@oit.edu)
// date: 02/07/2020

#pragma once
#include "cDeclNode.h"
#include "cVarDeclsNode.h"
#include "cBlockNode.h"
#include "cSymbol.h"

class cProcDeclNode : public cDeclNode
{
    public:
        //**************************************************
        // constructor
        cProcDeclNode(cSymbol * symbol = nullptr, 
                      cVarDeclsNode * decls = nullptr, 
                      cBlockNode * block = nullptr) : cDeclNode() 
        {
            if (symbol != nullptr)
            {
                AddChild(symbol);
                symbol->SetDecl(this);
            }

            if (decls != nullptr)
            {
                AddChild(decls);
            }

            if (block != nullptr)
            {
                AddChild(block);
            }
        }
      
       //***************************************************
       // returns a string with the node type
       virtual string NodeType() { return "proc"; } 

       //***************************************************
       // defines the visit method for this node
       virtual void Visit(cVisitor * visitor) { visitor->Visit(this); }
};
