//**********************************************************
// file name: cExprNode.h
// purpose: defines base class for all expressions.
// author: Rowan Parker (rowan.parker@oit.edu)
// date: 02/03/2020

#pragma once
#include "cStmtNode.h"

class cExprNode : public cStmtNode
{
    public:
        //**************************************************
        // constructor
        cExprNode() : cStmtNode() {}
};
