//**********************************************************
// filename: cDeclNode.h
// purpose: defines base class for all declarations.
// author: Rowan Parker (rowan.parker@oit.edu)
// date: 02/03/2020

#pragma once
#include "cAstNode.h"

class cDeclNode : public cAstNode
{
    public:
        //**************************************************
        // constructor
        cDeclNode() : cAstNode() {}
};
