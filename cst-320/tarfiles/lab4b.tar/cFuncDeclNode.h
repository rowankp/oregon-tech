//**********************************************************
// filename: cFuncDeclNode
// purpose: defines an ast node for function  declarations.
// author: Rowan Parker (rowan.prker@oit.edu)
// date: 02/07/2020

#pragma once
#include "cDeclNode.h"
#include "cVarDeclsNode.h"
#include "cBlockNode.h"
#include "cSymbol.h"

class cFuncDeclNode : public cDeclNode
{
    public:
        //**************************************************
        // constructor
        cFuncDeclNode(cSymbol * name = nullptr, 
                      cDeclNode * type = nullptr,
                      cDeclsNode * decls = nullptr, 
                      cBlockNode * block = nullptr) : cDeclNode() 
        {
            if (name != nullptr)
            {
                AddChild(name);
                name->SetDecl(this);
            }
            
            if (type != nullptr)
            {
                AddChild(type);
            }

            if (decls != nullptr)
            {
                AddChild(decls);
            }

            if (block != nullptr)
            {
                AddChild(block);
            }
        }

       //***************************************************
       // adds a block decl as a child
       void AddBlock(cBlockNode * block)
       {
           if (block != nullptr)
           {
               AddChild(block);
           }
       }

       //***************************************************
       // returns a string with the node type
       virtual string NodeType() { return "func"; } 

       //***************************************************
       // defines the visit method for this node
       virtual void Visit(cVisitor * visitor) { visitor->Visit(this); }
};
