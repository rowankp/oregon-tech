//**********************************************************
// filename: cFuncExprNode.h
// purpose: defines an ast node for a function call.
// author: Rowan Parker
// date: 02/09/2020

#pragma once
#include "cExprNode.h"
#include "cSymbol.h"

class cFuncExprNode : public cExprNode
{
    public: 
    cFuncExprNode(cSymbol * symbol, cExprListNode * expr) : cExprNode()
    {
        AddChild(symbol);
        AddChild(expr);
    }

    virtual string NodeType() { return "funcCall"; }

    virtual void Visit(cVisitor * visitor) { visitor->Visit(this); }
};
