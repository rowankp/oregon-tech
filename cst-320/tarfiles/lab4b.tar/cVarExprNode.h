//**********************************************************
// filename: cVarExprNode.h
// purpose: class definition for cVarExprNode.
// author: Rowan Parker
// date: 02/03/2020

#pragma once
#include "cExprNode.h"
#include "cExprListNode.h"
#include "cSymbol.h"

class cVarExprNode : public cExprNode
{
    public:
    //******************************************************
    // constructor 
    cVarExprNode(cSymbol * symbol) : cExprNode()
    {
        AddChild(symbol);
    }

    //******************************************************
    // add symbol child
    void AddSymbol(cSymbol * symbol)
    {
        AddChild(symbol);
    }

    //******************************************************
    // add expr list
    void AddExprList(cExprListNode * expr)
    {
        AddChild(expr);
    }

    //******************************************************
    // return the node type
    virtual string NodeType() { return "varref"; }

    //******************************************************
    // define the visit method for this node
    virtual void Visit(cVisitor * visitor) { visitor->Visit(this); }
};
